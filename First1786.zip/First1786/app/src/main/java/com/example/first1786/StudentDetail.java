package com.example.first1786;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.example.first1786.entities.Mark;
import com.example.first1786.entities.Student;

import java.util.List;

public class StudentDetail extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_detail);

        Intent intent = getIntent();
        int studentId = intent.getIntExtra("studentId",0);
        String name = intent.getStringExtra("studentName");

        TextView tvId = findViewById(R.id.tvId);
        EditText editTextName = findViewById(R.id.editTextName);

        tvId.setText(String.valueOf(studentId));
        editTextName.setText(name);

        Button btnSave = findViewById(R.id.btnSaveMark);
        btnSave.setOnClickListener(view -> {
            EditText subject = findViewById(R.id.editTextSubject);
            EditText mark = findViewById(R.id.editTextMark);
            DatabaseHandler dbHelper = new DatabaseHandler(this);
            dbHelper.insertMark(studentId,subject.getText().toString(),
                        Double.parseDouble(mark.getText().toString()));

            //
            List<Mark> marks = dbHelper.getMarks(studentId);
            ArrayAdapter<Mark> arrayAdapter
                    = new ArrayAdapter<Mark>(this, android.R.layout.simple_list_item_1
                    , marks);

            ListView listView = findViewById(R.id.listViewMarks);
            listView.setAdapter(arrayAdapter);
        });

        Button btnView = findViewById(R.id.viewMarks);
        btnView.setOnClickListener(view -> {
            DatabaseHandler dbHelper = new DatabaseHandler(this);
            List<Mark> marks = dbHelper.getMarks(studentId);
            ArrayAdapter<Mark> arrayAdapter
                    = new ArrayAdapter<Mark>(this, android.R.layout.simple_list_item_1
                    , marks);

            ListView listView = findViewById(R.id.listViewMarks);
            listView.setAdapter(arrayAdapter);
        });

    }
}