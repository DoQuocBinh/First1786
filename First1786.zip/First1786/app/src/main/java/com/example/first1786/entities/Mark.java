package com.example.first1786.entities;

public class Mark {
    private int mark_id;
    private int student_id;
    private String subject;
    private double mark;

    public int getMark_id() {
        return mark_id;
    }

    public void setMark_id(int mark_id) {
        this.mark_id = mark_id;
    }

    public int getStudent_id() {
        return student_id;
    }

    public void setStudent_id(int student_id) {
        this.student_id = student_id;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public double getMark() {
        return mark;
    }

    public void setMark(double mark) {
        this.mark = mark;
    }

    public Mark(int mark_id, int student_id, String subject, double mark) {
        this.mark_id = mark_id;
        this.student_id = student_id;
        this.subject = subject;
        this.mark = mark;
    }

    @Override
    public String toString() {
        return "Mark{" +
                "mark_id=" + mark_id +
                ", student_id=" + student_id +
                ", subject='" + subject + '\'' +
                ", mark=" + mark +
                '}';
    }
}
