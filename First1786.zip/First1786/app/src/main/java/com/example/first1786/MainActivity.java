package com.example.first1786;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.example.first1786.entities.Student;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnClear = findViewById(R.id.btnClear);
        Button btnSave = findViewById(R.id.btnSave);
        EditText txtName = findViewById(R.id.txtName);
        EditText txtAge = findViewById(R.id.txtAge);

        btnClear.setOnClickListener(view -> {
            txtName.setText("");
            txtAge.setText("");
        });
        btnSave.setOnClickListener(view -> {
            String name = txtName.getText().toString();
            int age;
            try{
                 age = Integer.parseInt(txtAge.getText().toString()) ;
            }catch (Exception ex){
                txtAge.setError("Tuoi phai la so Integer");
                return;
            }
            if(name.length()==0){
                txtName.setError("Ten khong de trang!");
                return;
            }

            //Save database
            DatabaseHandler dbHandler = new DatabaseHandler(getApplicationContext());
            dbHandler.insertStudent(txtName.getText().toString(),Integer.parseInt(txtAge.getText().toString()));
            Toast.makeText(getApplicationContext(),"Student saved!",Toast.LENGTH_SHORT).show();

        });
        Button btnViewAll = findViewById(R.id.btnViewAll);
        btnViewAll.setOnClickListener(view -> {
            DatabaseHandler dbHelper = new DatabaseHandler(this);

            List<Student> students = dbHelper.getStudents();
            ArrayAdapter<Student> arrayAdapter
                    = new ArrayAdapter<Student>(this, android.R.layout.simple_list_item_1 , students);

            ListView listView = findViewById(R.id.listViewStudent);
            listView.setAdapter(arrayAdapter);

            //register event: click on Listview Item
            listView.setOnItemClickListener((adapterView, view1, i, l) -> {
                Student selectedStudent = students.get(i);
                Toast.makeText(getApplicationContext(), selectedStudent.getName(),
                        Toast.LENGTH_SHORT).show();
                openDetails(selectedStudent);
            });


        });
    }

    private void openDetails(Student selectedStudent) {
        Intent intent = new Intent(MainActivity.this,StudentDetail.class);
        intent.putExtra("studentId",selectedStudent.getStudent_id());
        intent.putExtra("studentName",selectedStudent.getName());
        startActivity(intent);
    }
}