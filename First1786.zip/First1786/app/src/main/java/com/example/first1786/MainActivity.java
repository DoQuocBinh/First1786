package com.example.first1786;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnClear = findViewById(R.id.btnClear);
        Button btnSave = findViewById(R.id.btnSave);
        EditText txtName = findViewById(R.id.txtName);
        EditText txtAge = findViewById(R.id.txtAge);

        btnClear.setOnClickListener(view -> {
            txtName.setText("");
            txtAge.setText("");
        });
        btnSave.setOnClickListener(view -> {
            String name = txtName.getText().toString();
            int age;
            try{
                 age = Integer.parseInt(txtAge.getText().toString()) ;
            }catch (Exception ex){
                txtAge.setError("Tuoi phai la so Integer");
                return;
            }
            if(name.length()==0){
                txtName.setError("Ten khong de trang!");
                return;
            }
            Toast.makeText(this, "Xin chao " + name
                    + " -" + age + " tuoi", Toast.LENGTH_SHORT).show();

        });
    }
}