package com.example.first1786;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.example.first1786.entities.Mark;
import com.example.first1786.entities.Student;

import java.util.ArrayList;

public class DatabaseHandler extends SQLiteOpenHelper {
    //ten database
    private static final String DATABASE_NAME = "StudentCourses";
    //ten bang
    private static final String TABLE_STUDENT = "Students";
    private static final String TABLE_MARK = "Marks";

    //ten cac column trong bang
    public static final String STUDENT_ID = "student_id";
    public static final String NAME = "name";
    public static final String AGE = "age";

    //ten cac column trong bang
    public static final String Mark_ID = "mark_id";
    public static final String SUBJECT = "subject";
    public static final String FK_STUDENT_ID = "student_id";
    public static final String MARK = "mark";


    private SQLiteDatabase database;

    private static final String TABLE_STUDENT_CREATE = String.format(
            "CREATE TABLE %s (" +
                    "   %s INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "   %s TEXT, " +
                    "   %s INTEGER)",
            TABLE_STUDENT, STUDENT_ID, NAME, AGE);


    private static final String TABLE_MARK_CREATE = String.format(
            "CREATE TABLE %s (" +
                    "   %s INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "   %s INTEGER, " +
                    "   %s TEXT, " +
                    "   %s INTEGER)",
            TABLE_MARK, Mark_ID, FK_STUDENT_ID, SUBJECT, MARK);

    public DatabaseHandler(Context context) {
        super(context, DATABASE_NAME, null, 2);
        database = getWritableDatabase();
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_STUDENT);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_MARK);
        onCreate(db);
    }

    public long insertStudent(String name, Integer age) {
        ContentValues rowValues = new ContentValues();
        rowValues.put(NAME, name);
        rowValues.put(AGE, age);
        return database.insertOrThrow(TABLE_STUDENT, null, rowValues);
    }

    public long insertMark(Integer studentId, String subject, Double mark) {
        ContentValues rowValues = new ContentValues();
        rowValues.put(FK_STUDENT_ID, studentId);
        rowValues.put(SUBJECT, subject);
        rowValues.put(MARK,mark);
        return database.insertOrThrow(TABLE_MARK, null, rowValues);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(TABLE_STUDENT_CREATE);
        db.execSQL(TABLE_MARK_CREATE);
    }
    public ArrayList<Student> getStudents() {
        Cursor cursor = database.query(TABLE_STUDENT, new String[] {STUDENT_ID, NAME, AGE},
                null, null, null, null, STUDENT_ID);

        ArrayList<Student> results = new ArrayList<>();
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            int id = cursor.getInt(0);
            String name = cursor.getString(1);
            Integer age = cursor.getInt(2);

            Student student = new Student();
            student.setName(name);
            student.setStudent_id(id);
            student.setAge(age);

            results.add(student);

            cursor.moveToNext();
        }
        return results;
    }
    public ArrayList<Mark> getMarks(int studentId) {
        String MY_QUERY = "SELECT b.mark_id, b.subject, b.mark, a.name FROM "+ TABLE_STUDENT+ " a INNER JOIN "+
                TABLE_MARK + " b ON a.student_id=b.student_id WHERE a.student_id=?";
        Cursor cursor = database.rawQuery(MY_QUERY,new String[]{String.valueOf(studentId)});

        ArrayList<Mark> results = new ArrayList<>();

        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            int mark_id = cursor.getInt(0);
            String subject = cursor.getString(1);
            Double mark = cursor.getDouble(2);
            String studentName = cursor.getString(3);

            Mark markRow = new Mark(mark_id,studentId,subject,mark);
            results.add(markRow);
            cursor.moveToNext();
        }
        return results;

    }
}
